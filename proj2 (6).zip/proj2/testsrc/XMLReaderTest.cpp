#include <iostream>
#include <cstdlib>

int main() {
    std::cout << "🔥🔥🔥 MAIN FUNCTION STARTED 🔥🔥🔥" << std::endl;
    system("pause"); // 🛑 Forces Windows to pause execution (so you can see the output)
    return 0;
}

